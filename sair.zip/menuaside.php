<?php
echo '
                    <aside>
                    <h3>Menu de Opções</h3>
                    <ul>
                        <li><a href="cadAluno.php">Incluir Aluno</a></li>
                        <li><a href="#">Admin.</a></li>
                        <li><a href="#">Relatórios</a></li>
                    </ul>
                        
                    </aside>';

?>