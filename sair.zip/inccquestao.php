<?php

// Ativa o bloco que conecta ao banco de dados
require_once 'conecta.php';

include 'cabecalho.php';

if (isset($_COOKIE['Nivel']))
{
    
    $nivel =$_COOKIE['Nivel'];
    $nome  =$_COOKIE['Nome'];
    $Email =$_COOKIE['Email'];
    $codigo=$_COOKIE['Codigo'];
    $codigo_aluno=$codigo;
                    
    if ($nivel=='Professor')
    {
        
    
?>
<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="index.php"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
					<li><a href="index.php">Professor</a><i class="icon-angle-right"></i></li>
					<li class="active">Cadastrar Prova</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
        
<section id="content">
<div class="container">

<div class="row">
    <div class="col-lg-12">
                        <h1>Clique em incluir para adicionar a questao:</h1>
                        <p>...</p>
                    
                    <?php
                    if(isset($_GET['prova']))
                    {
                    $codigo_prova=$_GET['prova'];
                    $sql="select * from cadastro_questoes";
                    $r=mysqli_query($con, $sql);
                    
                    // Acrescentar filtros e mudanças de páginas 
                    //
                    
                    while ($dados=mysqli_fetch_array($r))
                    {
                        $vsql="select * from tabela_questoes where Questao=".$dados['Codigo']." and Codigo_Prova='".$codigo_prova."'";
                        $jaexiste=0;
                        $vr=mysqli_query($con,$vsql);
                        while ($vdados=mysqli_fetch_array($vr))
                        {  
                             
                                      $jaexiste=1;
                                 
                        }
                        if ($jaexiste==0) {
                        echo "<p><form method=\"POST\" action=\"incqbd.php\">";
                        }
                        else
                            {
                        echo "<p><form method=\"POST\" action=\"remqbd.php\">";
                        }
                        echo "<table><tr><td width=4>";
                        echo $dados['Codigo'];
                        echo "&nbsp;&nbsp;&nbsp;</td><td width=800>";
                        echo $dados['Questao'];
                        echo "</td><td>&nbsp;&nbsp;<input type=\"hidden\" name=\"codigo_questao\" value=\"".$dados['Codigo']."\">";
                        echo "<input type=\"hidden\" name=\"codigo_prova\" value=\"".$codigo_prova."\">";
                        
                        if ($jaexiste==0) {
                        echo "<input type=\"submit\" name=\"incluir\" value=\"Incluir\"></td></tr></table>";
                        }
                        else
                            {
                        echo "<input type=\"submit\" name=\"excluir\" value=\"Remover\"></td></tr></table>";
                        }
                        echo "</form></p><hr>";
                    }
                    }
                    else
                    {
                    echo "erro!";
                    }
                    
    }
}
                       ?>
           

                 
 

            </div> <!-- #main -->
        </div> <!-- #main-container -->
</div>
</section>

        <?php
                  include 'footer.php';
    
        ?>  
        

        