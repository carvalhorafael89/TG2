<?php

// Ativa o bloco que conecta ao banco de dados
require_once 'conecta.php';
include 'cabecalho.php';

if (isset($_COOKIE['Nivel']))
{
    
    $nivel =$_COOKIE['Nivel'];
    $nome  =$_COOKIE['Nome'];
    $Email =$_COOKIE['Email'];
    $codigo=$_COOKIE['Codigo'];
    $codigo_aluno=$codigo;
                    

?>
<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="index.php"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
					<li><a href="index.php">Alunos</a><i class="icon-angle-right"></i></li>
					<li class="active">Realizar Prova/Simulados</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
        
<section id="content">
<div class="container">
<div class="row">
  <div class="col-lg-12">
        
    <?php

                if (isset($_GET['codigo_prova']))
                {
                    if (isset($_GET['codigo_aluno']))  
                    {
                    $codigo_prova=$_GET['codigo_prova'];
                    $codigo_aluno=$_GET['codigo_aluno'];
                    if (isset($_GET['numero']))
                    {
                        $numero=$_GET['numero'];
                        
                    }
                    else
                    {
                        $numero=1;
                    }
                 
                    $total_questoes=0;
                    $sql="SELECT * from gabaritos where Aluno=".$codigo_aluno." and Prova='".$codigo_prova."'";
                    $data=mysqli_query($con,$sql);
                    while ($dados=mysqli_fetch_array($data))
                    {
                        $total_questoes=$total_questoes+1;
                    }
                    
                    
                    if ($numero>$total_questoes)
                    {
                        $numero=$total_questoes;
                    }
                    if ($numero<1)
                    {
                        $numero=1;
                    }

                    $sql="select * from gabaritos where Numero='".$numero."' and Aluno='".$codigo_aluno."' and Prova='".$codigo_prova."'";
                    $r=mysqli_query($con,$sql);
                    echo "<h2><small>Questão $numero de $total_questoes</small></h2>";
                    echo "<form role=\"form\" class=\"register-form\" method=\"POST\" action=\"pquest.php\">";
                    
                    
                    while ($dados=mysqli_fetch_array($r))
                    {
                        $resposta=$dados['Resposta_Aluno'];
                        if ($resposta!='Z')
                        {
                            echo "<h2><small><font color=red>Questão já respondida!</font></small></h2>";
                        }
                        $finalizado=$dados['Finalizado'];
                        $rcorreta=$dados['Resposta_Correta'];
                        $bqsql="select * from cadastro_questoes where Codigo='".$dados['Questao']."'";
                        //echo $bqsql;
                        
                        
                        
                        $resp1=mysqli_query($con,$bqsql);
                        
                        
                        
                        
                        while ($bqdados=mysqli_fetch_array($resp1))
                        {
                            
                            echo "<h3>Questão: ".$numero."<br><small> (Esta questão refere-se à disciplina: ".$bqdados['Disciplina'].")</small></h3>";
                            echo "<br>";
                            echo "<h3>".$bqdados['Questao']."</h3>";
                            echo "<br>";
                            echo "Aqui vai a figura";
                            echo "<br>";
                            
                            
                            echo "<table><tr><td>";
                            echo "<h4><input type=\"radio\" name=\"resposta\" value=\"A\" ";
                            if ($resposta=='A') {  echo " checked>"; } else { echo ">"; }
                            
                            echo " A </h4>";
                            echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;<td><h4>";
                            if($finalizado=="Sim" && $rcorreta=='A') { echo '<font color="red" >'; } else { echo '<font color="green" >'; }
                            echo $bqdados['RespostaA'];
                            echo '</font>';
                            echo "</h4></td></tr></table>";
                            
                            echo "<table><tr><td>";
                            echo "<h4><input type=\"radio\" name=\"resposta\" value=\"B\" ";
                            if ($resposta=='B') {  echo " checked>"; } else { echo ">"; }
                            
                            echo " B </h4>";
                            echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;<td><h4>";
                            if($finalizado=="Sim" && $rcorreta=='B') { echo '<font color="red" >'; } else { echo '<font color="green" >'; }
                            echo $bqdados['RespostaB'];
                            echo '</font>';
                            echo "</h4></td></tr></table>";
                            
                            echo "<table><tr><td>";
                            echo "<h4><input type=\"radio\" name=\"resposta\" value=\"C\" ";
                            if ($resposta=='C') {  echo " checked>"; } else { echo ">"; }
                            
                            echo " C </h4>";
                            echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;<td><h4>";
                           if($finalizado=="Sim" && $rcorreta=='C') { echo '<font color="red" >'; } else { echo '<font color="green" >'; }
                            echo $bqdados['RespostaC'];
                            echo '</font>';
                            echo "</h4></td></tr></table>";
                            
                            
                            echo "<table><tr><td>";
                            echo "<h4><input type=\"radio\" name=\"resposta\" value=\"D\" ";
                            if ($resposta=='D') {  echo " checked>"; } else { echo ">"; }
                            
                            echo " D </h4>";
                            echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;<td><h4>";
                            if($finalizado=="Sim" && $rcorreta=='D') { echo '<font color="red" >'; } else { echo '<font color="green" >'; }
                            echo $bqdados['RespostaD'];
                            echo '</font>';
                            echo "</h4></td></tr></table>";
                            
                            
                            
                            echo "<table><tr><td>";
                            echo "<h4><input type=\"radio\" name=\"resposta\" value=\"E\" ";
                            if ($resposta=='E') {  echo " checked>"; } else { echo ">"; }
                            
                            echo " E </h4>";
                            echo "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;<td><h4>";
                            if($finalizado=="Sim" && $rcorreta=='E') { echo '<font color="red" >'; } else { echo '<font color="green" >'; }
                            echo $bqdados['RespostaE'];
                            echo '</font>';
                            echo "</h4></td></tr></table>";
                            
                            echo "<br>";                              
                        }
                        
                    }
                    echo "<input type=\"hidden\" name=\"codigo_prova\" value=\"".$codigo_prova."\">";
                    echo "<input type=\"hidden\" name=\"codigo_aluno\" value=\"".$codigo_aluno."\">";
                    echo "<input type=\"hidden\" name=\"numero\" value=\"".$numero."\">";
                    
                    if ($finalizado!='Sim') {
                    echo '
                        <div class="row">
				<div class="col-xs-12 col-md-6"><input type="submit" value="Gravar Resposta" class="btn btn-primary btn-block btn-lg" tabindex="7"></div>
				
			</div>
                        ';
                    }
                    echo "</form>";
                    echo "<br><br>";
                    
                    $anterior=$numero-1;
                    if ($anterior>=1)
                    {
                        
                        echo "<a href=comeca.php?codigo_prova=".$codigo_prova."&codigo_aluno=".$codigo_aluno."&numero=".$anterior."><< Questão Anterior</a>&nbsp;&nbsp;&nbsp;";
                    }
                    
                    $posterior=$numero+1;
                    if ($posterior<=$total_questoes)
                    {
                        echo "&nbsp;&nbsp;&nbsp;<a href=comeca.php?codigo_prova=".$codigo_prova."&codigo_aluno=".$codigo_aluno."&numero=".$posterior.">Próxima Questão >></a>";
                    }
                    
                    if ($finalizado=='Sim')
                    {
                      
                    echo "&nbsp;&nbsp;&nbsp;<a href=verifprv.php?codigo_prova=".$codigo_prova."&codigo_aluno=".$codigo_aluno.">Verificar Resultados</a>";
                     
                    }
                    else
                    {
                    if ($numero==$total_questoes) {
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=finalprv.php?codigo_prova=".$codigo_prova."&codigo_aluno=".$codigo_aluno.">[ Finaliza Prova ]</a>";
                    }
                    }
                    }
                }
}        

else
{
    $voltar="login.php";
    header("Location: $voltar");
}
?>
  </div>
</div>
</div>
</section>
<?php include 'footer.php'; ?>
