<?php

// Ativa o bloco que conecta ao banco de dados
require_once 'conecta.php';
include 'cabecalho.php';

if (isset($_COOKIE['Nivel']))
{
    
    $nivel =$_COOKIE['Nivel'];
    $nome  =$_COOKIE['Nome'];
    $Email =$_COOKIE['Email'];
    $codigo=$_COOKIE['Codigo'];
    $codigo_aluno=$codigo;
                    

?>
<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="index.php"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
					<li><a href="index.php">Alunos</a><i class="icon-angle-right"></i></li>
					<li class="active">Realizar Prova/Simulados</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
        
<section id="content">
<div class="container">
<div class="row">
  <div class="col-lg-12">
<?php

                if (isset($_GET['codigo_prova']))
                {
                    $codigo_aluno=0;
                    $codigo_prova=$_GET['codigo_prova'];
                    
                    $lista="select DISTINCT Aluno from gabaritos where Prova='".$codigo_prova."'";
                    $l=mysqli_query($con,$lista);
                    while ($lc=mysqli_fetch_array($l))
                    {
                        $codigo_aluno=$lc['Aluno'];
                        //echo $codigo_aluno;
                    
                    
                    echo "<table>";
                    
                    $temp="select * from cadastro_alunos where Codigo=".$codigo_aluno;
                    $temp2=mysqli_query($con,$temp);
                    while ($temp3=mysqli_fetch_array($temp2))
                    {
                        $nome_aluno=$temp3['Nome'];
                        $ra_aluno=$temp3['RA'];
                    }
                    echo "<tr><td>$codigo_aluno</td><td>$ra_aluno</td><td>$nome_aluno</td>";
                    
                                   
                    $total_questoes=0;
                    $pontos=0;
                    $sql="SELECT * from gabaritos where Aluno=".$codigo_aluno." and Prova='".$codigo_prova."'";
                    $data=mysqli_query($con,$sql);
                    // echo "<table>";
                    //echo "<tr><td><h4>Questão</h4></td><td>&nbsp;&nbsp;&nbsp;</td><td><h4>Resposta do Aluno</h4></td><td>&nbsp;&nbsp;&nbsp;</td><td><h4>Resposta Correta</h4></td><td>&nbsp;&nbsp;&nbsp;</td><td><h4>Situação</h4></td></tr>";
                    while ($dados=mysqli_fetch_array($data))
                    {
                        echo "<td>";
                        echo $dados['Resposta_Aluno'];
                        //echo $dados['Resposta_Correta'];
                        echo "</td>";
                       /* if ($dados['Resposta_Aluno']==$dados['Resposta_Correta'])
                        {
                            echo "<font color=green>Correta</font>";
                            $pontos=$pontos+1;
                        }
                        else
                        {
                            echo "<font color=red>Incorreta</font>";
                        }
                         */
                       
                        //echo "</h4></td></tr>";
                       $total_questoes=$total_questoes+1;
                    }
                    
                    echo "<td>";
                    echo $pontos;
                    echo "</td>";
                    
                    echo "</tr>";
                    
                   // $nota=$pontos/$total_questoes*10;
                    //echo "</h2><h2>Nota (0 a 10): ".$nota."</h2>";
                    //$sql= "UPDATE gabaritos SET Finalizado='Sim' WHERE Aluno=".$codigo_aluno." and Prova='".$codigo_prova."'";
                //echo $sql;
                
                   //echo $sql;
                   //mysqli_query($con, "insert into cursos (curso) values ('Eletr. Automotiva')");
                   //mysqli_query($con, $sql);
                    }
                    echo "</table>";
                }
}
                

else
{
    $voltar="login.php";
    header("Location: $voltar");
}
?>
 </div>
</div>
</div>
</section>
<?php include 'footer.php'; ?>