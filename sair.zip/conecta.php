<?php
// Programa para a realização de simulados on-line
// Professor Renato Luiz Cardoso
// Set/2018
// Conexão com o banco de dados SIMULADOS

// Dados necessários para conexão

$servidor="renatocardoso.mysql.dbaas.com.br";
$udb="renatocardoso";
$senha="Carina9210@";
$bdados="renatocardoso";

// Criando a conexão com a base de dados
$con = mysqli_connect($servidor,$udb,$senha,$bdados);

// Define a acentuação/tabela de caracteres na origem dos dados
mysqli_query($con,"SET NAMES utf8");

// Caso ocorra um erro, emite uma mensagem de falha
if (mysqli_connect_errno()) {
  echo "Falha na conexão com o mySQL: " . mysqli_connect_error();
    }
    
 // FIM

echo "
<!--\n 
Programa para a realização de provas e simulados on-line\n
Desenvolvido pelo Professor Renato Luiz Cardoso\n
Licença Creative Commons, uso livre desde que mantido o este cabeçalho.
Set/2018\n
\n
-->\n";
?>






























