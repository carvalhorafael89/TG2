<?php
// Programa para a realização de simulados on-line
// Professor Renato Luiz Cardoso
// Set/2018


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


// Constrói um menu superior padrão para todas as páginas.
//

echo '
       <div class="header-container">
            <header class="wrapper clearfix">
                <h1 class="title">Construtor de Simulados</h1>
                <nav>
                    <ul>
                        <li><a href="#">Provas</a></li>
                        <li><a href="#">Admin.</a></li>
                        <li><a href="#">Relatórios</a></li>
                    </ul>
                </nav>
            </header>
        </div>';
?>
